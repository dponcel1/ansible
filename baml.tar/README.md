# Roles for catalog

# The site.yml is for testing purposes to simulate passing in variables to the
# roles. The playbook to invoke the roles will be generated elsewhere with
# appropriate values determined by BAML team.